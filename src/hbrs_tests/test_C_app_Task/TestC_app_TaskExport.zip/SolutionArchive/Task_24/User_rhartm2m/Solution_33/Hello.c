#include <stdio.h>
// public static void main(String[] args) <= JAVA

int main(){
printf("Hello World!");
return 0;
}