#include <stdio.h>
#include <string.h>
#include <float.h>
#include "CUnit/Basic.h"

#define MAXTESTS 128



#ifdef CU_ASSERT_FLOAT_EQUAL
#undef CU_ASSERT_FLOAT_EQUAL
#endif
#define CU_ASSERT_FLOAT_EQUAL(actual, expected, txt)                    \
    {                                                                   \
       CU_assertImplementation(                                         \
          (feq(actual, expected)),                                      \
          __LINE__,                                                     \
          txt,                                                          \
          __FILE__,                                                     \
          "",                                                           \
          CU_FALSE);                                                    \
    }


#ifdef CU_ASSERT_EQUAL
#undef CU_ASSERT_EQUAL
#endif
#define CU_ASSERT_EQUAL(actual, expected, txt)                          \
    {                                                                   \
       CU_assertImplementation(                                         \
          ((actual) == (expected)),                                     \
          __LINE__,                                                     \
          txt,                                                          \
          __FILE__,                                                     \
          "",                                                           \
          CU_FALSE);                                                    \
    }


#ifdef CU_ASSERT
#undef CU_ASSERT
#endif
#define CU_ASSERT(actual, txt)                                          \
    {                                                                   \
       CU_assertImplementation(                                         \
          ((actual)),                                                   \
          __LINE__,                                                     \
          txt,                                                          \
          __FILE__,                                                     \
          "",                                                           \
          CU_FALSE);                                                    \
    }


#ifdef CU_ASSERT_STRING_EQUAL
#undef CU_ASSERT_STRING_EQUAL
#endif
#define CU_ASSERT_STRING_EQUAL(actual, expected)                        \
    {                                                                   \
        char *_s = "CU_ASSERT_STRING_EQUAL(\"%s\", \"%s\")";            \
        unsigned int _l = strlen(actual) + strlen(expected) +           \
            strlen(_s) - 4 + 1;                                         \
        char _buf[_l];                                                  \
        _buf[_l]='\0';                                                  \
        snprintf(_buf, _l, _s, actual, expected);                       \
        CU_assertImplementation(                                        \
          !(strcmp((const char*)(actual), (const char*)(expected))),    \
           __LINE__,                                                    \
          _buf,                                                         \
          __FILE__,                                                     \
          "",                                                           \
          CU_FALSE);                                                    \
    }

typedef struct {
    const char  *name;
    CU_TestFunc func;
} t_test;


t_test tests[MAXTESTS] = {{NULL, NULL}};
t_test *current_test = tests;

void add_tests(void);

int
add_test(const char *name, CU_TestFunc func) {

    if (current_test-tests == MAXTESTS) {
        return -1;
    }

    current_test++;
    current_test->name = name;
    current_test->func = func;

    return 0;

} /* add_test */

/* It's a start... */
int
feq(float x, float y) {

    float max_rel_diff = FLT_EPSILON;
    float diff = fabs(x-y);
    x = fabs(x);
    y = fabs(y);

    float largest = (y > x) ? y : x;

    if (diff <= largest * max_rel_diff)
        return 1;

    return 0;

} /* feq */

int
main(int argc __attribute((__unused__)),
     char **argv __attribute((__unused__))) {

    CU_pSuite suite = NULL;
    int err;


    if (CUE_SUCCESS != CU_initialize_registry())
        return CU_get_error();

    suite = CU_add_suite("Tests", NULL, NULL);
    if (NULL == suite) {
        err = CU_get_error();
        CU_cleanup_registry();
        return err;
    }

    add_tests();

    t_test *t = tests;
    while (t++ < current_test) {
        if ((NULL == CU_add_test(suite, t->name, t->func))) {
            err = CU_get_error();
            CU_cleanup_registry();
            return err;
        }
    }


    CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();
    return CU_get_number_of_failures();

} /* main */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>

#ifdef HAS_MEMFD
#include <sys/syscall.h>
#include <linux/memfd.h>
#include <sys/mman.h>
#endif

#define F "/tmp/wrap.out"
#define FREE(p) if (p) {free(p); p = NULL;}
#define EXETEST(ex, name, ret, shouldexit)      \
  if (0 > ((*(ret)) = ex)) {                    \
      perror(name);                             \
      if (shouldexit)                           \
          exit(*(ret));                         \
      else                                      \
          return *(ret);                        \
  }



int
createBuffer() {
    int fd;
    int _void;


#ifdef HAS_MEMFD
    EXETEST(syscall(__NR_memfd_create, "warp", MFD_ALLOW_SEALING),
            "memfd_create",
            &fd,
            0);
#else
    EXETEST(open(F, O_CREAT|O_TRUNC|O_RDWR, S_IRUSR|S_IWUSR),
            "open",
            &fd,
            0);

    EXETEST(unlink(F),
            "unlink",
            &_void,
            0);
#endif

    return fd;

  } /* createBuffer */



int
getOutstream(int fd, char **buf) {
    int     _void;
    size_t  bufsize = 0;
    ssize_t bytesread = 0;


    EXETEST(fflush(stdout),
            "fflush",
            &_void,
            0);

    EXETEST(lseek(fd, 0, SEEK_SET),
            "lseek",
            &_void,
            0);

    do {
        *buf = realloc(*buf, bufsize + 16);
        memset(&(*buf)[bufsize], 0, 16);
        bytesread = read(fd, &(*buf)[bufsize], 16);
        bufsize += 16;
    } while (bytesread > 0);

    EXETEST(ftruncate(fd, 0),
            "ftruncate",
            &_void,
            0);

    return 0;

} /* getOutstream */



int
getApplicationOutput(const char *path,
                     char * const params[],
                     char **buf) {
    int     fd;
    pid_t   child;
    int     _void;
    int     wstatus;


    EXETEST(createBuffer(),
            "createBuffer",
            &fd,
            0);

    switch (fork()) {

    case 0:
        EXETEST(dup2(fd, STDOUT_FILENO),
                "dup2",
                &_void,
                0);

        EXETEST(execv(path, params),
                "execv",
                &_void,
                0);
        break;

    case -1:
        perror("fork");
        exit(-1);
        break;

    default:

        EXETEST(wait(&wstatus),
                "wait",
                &child,
                0);

        EXETEST(getOutstream(fd, buf),
                "getOutstream",
                &_void,
                0);

        close(fd);

        return WEXITSTATUS(wstatus);

    }

    /* Should'nt be reached... */
    return -1;

} /* getApplicationOutput */

void
test_hello(void) {
    int ret;
    char *buf = NULL;
    char * const application = "./Solution.out";
    char * const params[] = {"Solution.out", NULL};
    const char *expected = "Hello World!";

    if ((ret = getApplicationOutput(application, params, &buf))) {
        FREE(buf);
        CU_FAIL("Internal error starting MUT");
        return;
    }

    CU_ASSERT_STRING_EQUAL(buf, expected);
    FREE(buf);
} /* test_hello */


void
add_tests(void) {
    add_test("test_hello", test_hello);
} /* add_tests */
