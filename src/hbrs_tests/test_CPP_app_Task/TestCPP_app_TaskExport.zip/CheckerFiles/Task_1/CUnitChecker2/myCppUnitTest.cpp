// compile with: g++ -g myCppUnitTest.cpp -lcppunit

#include <cppunit/TestFixture.h>
#include <cppunit/extensions/HelperMacros.h>


#include <cppunit/CompilerOutputter.h>
#include <cppunit/extensions/TestFactoryRegistry.h>
// #include <cppunit/ui/text/TestRunner.h> /* deprecated argh */
#include <cppunit/ui/text/TextTestRunner.h>


#ifndef HELLOAPPTEST_H
#define HELLOAPPTEST_H

#include<string>

class HelloAppTest : public CppUnit::TestFixture {
  CPPUNIT_TEST_SUITE( HelloAppTest ); 
  CPPUNIT_TEST( test_output );   
  CPPUNIT_TEST_SUITE_END();

 public:
  void setUp(void) {fixture = new std::string("Hallo Welt");}    
  void tearDown(void) {delete fixture; fixture = NULL;} 

 protected:
  void test_output(void); 
  
 private:
   std::string *fixture;
};

#endif

CPPUNIT_TEST_SUITE_REGISTRATION( HelloAppTest );




#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <limits.h>

#ifdef HAS_MEMFD
#include <sys/syscall.h>
#include <linux/memfd.h>
#include <sys/mman.h>
#endif

#define F "/tmp/wrap.out"
#define FREE(p) if (p) {free(p); p = NULL;}
#define EXETEST(ex, name, ret, shouldexit)      \
  if (0 > ((*(ret)) = ex)) {                    \
      perror(name);                             \
      if (shouldexit)                           \
          exit(*(ret));                         \
      else                                      \
          return *(ret);                        \
  }



int
createBuffer() {
    int fd;
    int _void;


#ifdef HAS_MEMFD
    EXETEST(syscall(__NR_memfd_create, "warp", MFD_ALLOW_SEALING),
            "memfd_create",
            &fd,
            0);
#else
    EXETEST(open(F, O_CREAT|O_TRUNC|O_RDWR, S_IRUSR|S_IWUSR),
            "open",
            &fd,
            0);

    EXETEST(unlink(F),
            "unlink",
            &_void,
            0);
#endif

    return fd;

  } /* createBuffer */



int
getOutstream(int fd, char **buf) {
    int     _void;
    size_t  bufsize = 0;
    ssize_t bytesread = 0;


    EXETEST(fflush(stdout),
            "fflush",
            &_void,
            0);

    EXETEST(lseek(fd, 0, SEEK_SET),
            "lseek",
            &_void,
            0);

    do {
        *buf = (char*)realloc(*buf, bufsize + 16);
        memset(&(*buf)[bufsize], 0, 16);
        bytesread = read(fd, &(*buf)[bufsize], 16);
        bufsize += 16;
    } while (bytesread > 0);

    EXETEST(ftruncate(fd, 0),
            "ftruncate",
            &_void,
            0);

    return 0;

} /* getOutstream */



int
getApplicationOutput(const char *path,
                     char * const params[],
                     char **buf) {
    int     fd;
    pid_t   child;
    int     _void;
    int     wstatus;


    EXETEST(createBuffer(),
            "createBuffer",
            &fd,
            0);

    switch (fork()) {

    case 0:
        EXETEST(dup2(fd, STDOUT_FILENO),
                "dup2",
                &_void,
                0);

        EXETEST(execv(path, params),
                "execv",
                &_void,
                0);
        break;

    case -1:
        perror("fork");
        exit(-1);
        break;

    default:

        EXETEST(wait(&wstatus),
                "wait",
                &child,
                0);

        EXETEST(getOutstream(fd, buf),
                "getOutstream",
                &_void,
                0);

        close(fd);

        return WEXITSTATUS(wstatus);

    }

    /* Should'nt be reached... */
    return -1;

} /* getApplicationOutput */


void HelloAppTest::test_output(void) {

    // 
    int ret;
    char *buf = NULL;
    char * const application = (char * const)"./Solution.out";
    char * const params[] = {(char * const)"Solution.out", NULL};
    const char *expected = this->fixture->c_str(); //"Hallo Welt";

    if ((ret = getApplicationOutput(application, params, &buf))) {
        FREE(buf);
        CPPUNIT_FAIL("Internal error starting MUT");
        return;
    }

   // CPPUNIT_ASSERT((std::string(expected).size()) == (std::string(buf).size()));
    CPPUNIT_ASSERT_EQUAL(std::string(">")+std::string(expected)+std::string("<"),std::string(">")+std::string(buf)+std::string("<"));
    FREE(buf);
}


int RunTests(void) 
{
  // Get the top level suite from the registry
  CppUnit::Test *suite = CppUnit::TestFactoryRegistry::getRegistry().makeTest();

  // Adds the test to the list of test to run
  // CppUnit::TextUi::TestRunner runner;
  CppUnit::TextTestRunner runner;
  runner.addTest( suite );

  // Change the default outputter to a compiler error format outputter
  runner.setOutputter( new CppUnit::CompilerOutputter( &runner.result(),
                                                       std::cerr ) );
  // Run the tests.
  bool wasSucessful = runner.run();

  // Return error code 1 if the one of test failed.
  return wasSucessful ? 0 : 1;
}

int main(void) {
  return RunTests();
}